create
  definer = root@localhost procedure test_score(IN score int, OUT str varchar(20))
begin
    IF score>100 or score<0 THEN
        SET str='非法数字';
    elseif score>=80 THEN
        SET str='优秀';
    ELSEIF score>=60 THEN
        SET str='及格';
    ELSE 
        SET str='不及格';
    END IF;
end;

