create view empview as
select `heixj`.`emp`.`empno` AS `empno`, `heixj`.`emp`.`ename` AS `ename`, `heixj`.`emp`.`sal` AS `sal`
from `heixj`.`emp`;

