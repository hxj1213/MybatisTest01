create
  definer = root@localhost procedure test_inandOut(INOUT number int)
begin
   select number;
   set number=500;
end;

