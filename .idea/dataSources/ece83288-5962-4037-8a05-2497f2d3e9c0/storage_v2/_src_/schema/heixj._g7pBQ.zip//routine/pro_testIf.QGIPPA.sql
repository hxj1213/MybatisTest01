create
  definer = root@localhost procedure pro_testIf(IN num int, OUT str varchar(20))
begin
    if num=1 then
	set str='星期一';
    elseif num=2 then
	set str='星期二';
    elseif num=3 then
        set str='星期三';
    else 
	set str='输入错误';
    end if;
end;

