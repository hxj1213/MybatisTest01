create definer = root@localhost trigger tri_addEmp
  after INSERT
  on emp
  for each row
  insert into test_log(content) values('添加了一个员工');

