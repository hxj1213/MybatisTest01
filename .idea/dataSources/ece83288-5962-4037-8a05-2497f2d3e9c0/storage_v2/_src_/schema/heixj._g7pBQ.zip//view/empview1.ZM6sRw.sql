create view empview1 as
select `heixj`.`emp`.`empno` AS `编号`, `heixj`.`emp`.`ename` AS `姓名`, `heixj`.`emp`.`sal` AS `工资`
from `heixj`.`emp`;

