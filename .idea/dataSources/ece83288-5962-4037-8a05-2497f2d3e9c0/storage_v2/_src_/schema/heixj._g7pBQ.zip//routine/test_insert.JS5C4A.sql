create
  definer = root@localhost procedure test_insert()
begin
  declare i int default 0;
  while i<5 do
    INSERT INTO t_score(sname,english) VALUES('jack',78);
    set i=i+1;
  end while;
end;

