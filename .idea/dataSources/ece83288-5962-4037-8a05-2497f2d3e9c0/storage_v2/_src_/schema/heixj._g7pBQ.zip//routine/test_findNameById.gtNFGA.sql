create
  definer = root@localhost procedure test_findNameById(IN eid int, OUT empname varchar(20))
begin
   select ename into empname from emp where empno=eid;
end;

