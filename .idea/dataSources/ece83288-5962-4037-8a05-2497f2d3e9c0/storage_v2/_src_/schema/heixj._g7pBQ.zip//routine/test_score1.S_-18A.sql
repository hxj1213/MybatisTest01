create
  definer = root@localhost procedure test_score1(OUT str varchar(20))
begin
   -- 定义局部变量
   declare savg double;
   -- 查询平均分
   select avg(english) into savg from t_score;
   IF savg>=80 THEN
      SET str='优秀';
   ELSEIF savg>=60 THEN
      SET str='一般';
   ELSE
      SET str='差';
   end if;
end;

