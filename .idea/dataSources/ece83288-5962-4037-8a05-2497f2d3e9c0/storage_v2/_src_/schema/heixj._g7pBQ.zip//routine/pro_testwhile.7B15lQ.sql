create
  definer = root@localhost procedure pro_testwhile(IN num int, OUT result int)
begin
   declare i int default 1;
   declare vsum int default 0;
   while i<=num do
	set vsum=vsum+i;
	set i=i+1;
   end while;
   set result=vsum;
end;

