create
  definer = root@localhost procedure test_selemp()
begin
   select * from emp;
end;

