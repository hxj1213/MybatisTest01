create
  definer = root@localhost procedure pro_test()
begin
   select * from emp;
end;

