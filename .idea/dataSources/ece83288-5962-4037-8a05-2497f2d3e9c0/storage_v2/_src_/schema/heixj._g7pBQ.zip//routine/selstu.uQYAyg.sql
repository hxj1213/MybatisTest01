create
  definer = root@localhost procedure selstu()
BEGIN
   SELECT * FROM student;
END;

