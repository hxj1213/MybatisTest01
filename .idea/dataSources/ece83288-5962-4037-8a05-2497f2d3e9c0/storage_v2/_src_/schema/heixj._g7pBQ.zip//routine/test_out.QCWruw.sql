create
  definer = root@localhost procedure test_out(OUT str varchar(20))
begin
   -- 给输出参数赋值
   set str='hello_mysql';
end;

