create
  definer = root@localhost procedure pro_findByid2(IN eid int, OUT vname varchar(20))
begin
   select ename into vname from emp where empno=eid;
end;

