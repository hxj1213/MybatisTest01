create
  definer = root@localhost procedure test_sal(OUT str varchar(20))
BEGIN
    DECLARE vsal DOUBLE;
    SELECT AVG(sal) INTO vsal FROM emp;
    IF vsal>2000 THEN
        SET str='高';
    ELSEIF score>1000 THEN
        SET str='一般';
    ELSE 
        SET str='低';
    END IF;
END;

