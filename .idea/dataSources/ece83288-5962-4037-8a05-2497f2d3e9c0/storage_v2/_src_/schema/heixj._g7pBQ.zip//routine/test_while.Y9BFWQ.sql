create
  definer = root@localhost procedure test_while(IN number int, OUT result int)
begin
  -- int sum = 0;
  -- for(int i = 1;i<=number;i++)
  --  sum+=i
  -- 定义一个局部变量
  declare i int default 1;
  declare vsum int default 0;
  while i<=number do
     set vsum=vsum+i;
     set i=i+1;
  end while;
  set result=vsum;
end;

