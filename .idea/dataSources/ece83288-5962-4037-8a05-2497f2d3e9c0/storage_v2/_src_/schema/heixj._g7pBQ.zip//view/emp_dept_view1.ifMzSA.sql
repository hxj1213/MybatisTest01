create view emp_dept_view1 as
select `heixj`.`emp`.`ename` AS `ename`, `heixj`.`dept`.`dname` AS `dname`
from `heixj`.`emp`
       join `heixj`.`dept`
where (`heixj`.`emp`.`deptno` = `heixj`.`dept`.`deptno`);

