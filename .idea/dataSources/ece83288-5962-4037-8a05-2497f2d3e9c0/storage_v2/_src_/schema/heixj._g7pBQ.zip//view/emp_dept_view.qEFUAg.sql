create view emp_dept_view as
select `heixj`.`emp`.`ename` AS `员工姓名`, `heixj`.`dept`.`dname` AS `部门名称`
from `heixj`.`emp`
       join `heixj`.`dept`
where (`heixj`.`emp`.`deptno` = `heixj`.`dept`.`deptno`);

