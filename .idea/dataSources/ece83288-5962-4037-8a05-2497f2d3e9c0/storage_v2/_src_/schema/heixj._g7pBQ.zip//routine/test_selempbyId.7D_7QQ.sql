create
  definer = root@localhost procedure test_selempbyId(IN eid int)
BEGIN
   SELECT * FROM emp where empno=eid;
END;

