create
  definer = root@localhost procedure pro_testOut(OUT str varchar(20))
begin 
   set str='hello_mysql';
end;

