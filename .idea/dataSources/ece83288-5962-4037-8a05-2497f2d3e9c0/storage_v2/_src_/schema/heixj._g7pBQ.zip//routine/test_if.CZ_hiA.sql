create
  definer = root@localhost procedure test_if(IN i int, OUT str varchar(20))
begin
    if i=1 then
       set str='星期一';
    elseif i=2 then
       set str='星期二';
    elseif i=3 then
       set str='星期三';
    else 
       set str='输入错误';
    end if; 
end;

