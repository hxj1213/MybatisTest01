create
  definer = root@localhost procedure pro_findByid(IN eid int)
begin
	select * from emp where empno=eid;
end;

