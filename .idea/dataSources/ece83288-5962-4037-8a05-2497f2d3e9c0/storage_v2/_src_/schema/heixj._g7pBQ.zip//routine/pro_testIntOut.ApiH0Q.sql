create
  definer = root@localhost procedure pro_testIntOut(INOUT n int)
begin 
   select n;
   set n = 500;
end;

